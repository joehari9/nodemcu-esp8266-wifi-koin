var limitClickstats = 0; // 0 to disable 1 to enable click limit
var limitUserstats = 1; // 0 to disable 1 to enable user limit
var limitClicks = 10; // tentukan sendiri
var limitUser = 20; // sesuaikan dengan kemampuan mikrotik
var scrollingtext = "<b><i>Penting !</i></b><i> Harap gunakan satu browser saja untuk login dan logout.</i>";

var modal1 = document.getElementById("myModal");
var loader = document.getElementById("load");
var Notif = document.getElementById("notif");
var time = new Date().getTime();

$("#marquee").html(scrollingtext);

function setCookie(cName, cValue, expDays) {
        let date = new Date();
        date.setTime(date.getTime() + (expDays * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = cName + "=" + cValue + "; " + expires + "; path=/";
}

function getCookie(name) {
      let result = document.cookie.match("(^|[^;]+)\\s*" + name + "\\s*=\\s*([^;]+)");
  return result ? result.pop() : "";
}

function deleteCookie(name){
  document.cookie = name+"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
}


var s;
if (s==true){
$("#status").html("<b>&nbsp;&nbsp; CONNECTED&nbsp;&nbsp;</b>");
$("#status").css("background-color", "green");
}else{
$("#status").html("<b>&nbsp;&nbsp; DISCONNECTED&nbsp;&nbsp;</b>");
$("#status").css("background-color", "red");
}

function pad(n) {
    return (n < 10 ? "0" + n : n);
  }
function timer() {
  if (s==true){
  var days        = Math.floor(seconds/24/60/60);
  var hoursLeft   = Math.floor((seconds) - (days*86400));
  var hours       = Math.floor(hoursLeft/3600);
  var minutesLeft = Math.floor((hoursLeft) - (hours*3600));
  var minutes     = Math.floor(minutesLeft/60);
  var remainingSeconds = seconds % 60;
  
  $("#countdown").html("<b>"+pad(days) + ":" + pad(hours) + ":" + pad(minutes) + ":" + pad(remainingSeconds)+"</b>");
  if (seconds == 0) {
    clearInterval(countdownTimer);
    $("#countdown").html("Timeout");
  } else {
    seconds--;
  }
  }
}
setInterval(function(){
  timer();
},1000);

var g;
if (g == true){
  loader.style.display = "block";
  loader.innerHTML=" <div class='ajax-loader'></div>";
  window.setTimeout(function () {
  Notif.style.display = "block";
  Notif.innerHTML="<b>Klik <a href='status.html'><font color='#FBD3E9'><i>disini</i></font></a> jika tidak dialihkan otomatis !</b>";
  }, 3000);
}

setInterval(function(){
   $("#mytbl").load("status.html #mytbl" );
}, 1000); 


function cekname(){
  if(s == true && getCookie("kode") == "" || getCookie("kode") !== name){
  setCookie("kode",name,"1");
 }
 deleteCookie("clicks");
}

var clicks;
function initiateClicks() {
    var clickStr = getCookie("clicks");
    if(clickStr == "" ){
        setCookie("clicks", 0,"1");
        clicks = 0;
    }else{
        clicks = parseInt(clickStr);   
    }
}

function doClick() {
    clicks += 1;
    setCookie("clicks", clicks,"1");
}

function clearClicks() {
  if(parseInt(getCookie("clicks")) >= limitClicks){
    deleteCookie("clicks");
  }
}

function getdata(filePath) {
  var result = null;
  var xmlhttp;
  if (window.XMLHttpRequest) {
    xmlhttp=new XMLHttpRequest();  
   } else {
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  xmlhttp.open("GET", filePath, false);
  xmlhttp.send();
  if (xmlhttp.status==200) {
    result = xmlhttp.responseText;
  }
  return result;
}
          
function include(arr,obj) {
    return (arr.indexOf(obj) != -1);
}


$(document).ready(function(){
$("#insertCoin").click(function(){
var host = getdata("host.txt");
var aktif = getdata("on.txt");
var lastime = getdata("lastime.txt");
var res = getdata("counter.txt").split(",");
loader.style.display = "block";
loader.innerHTML=" <div class='ajax-loader'></div>";
if(limitClickstats == 1 && include(res,mac) == true) {
  window.setTimeout(function () {
  loader.style.display = "none";
  modal1.style.display = "block";
  modal1.innerHTML="<div class='kawol-isi'><b>Mohon maaf anda telah mencapai limit klik tanpa memasukkan koin!</b>";
  }, 7000);
  window.setTimeout(function () {
  $(modal1).fadeOut(1500);
 }, 10000);
 }else if(limitUserstats == 1 && aktif >= limitUser){
  window.setTimeout(function () {
  loader.style.display = "none";
  modal1.style.display = "block";
  modal1.innerHTML="<div class='kawol-isi'><b>Mohon maaf system telah mencapai limit user!</b>";
  }, 7000);
  window.setTimeout(function () {
  $(modal1).fadeOut(1500);
 }, 10000);
 }else if(time - lastime <= 10000){
  window.setTimeout(function () {
  loader.style.display = "none";
  modal1.style.display = "block";
  modal1.innerHTML="<div class='kawol-isi'><strong>Kesalahan !</strong><br> jaringan sedang sibuk cobalah beberapa saat lagi.</div>";
  }, 7000);
  window.setTimeout(function () {
  $(modal1).fadeOut(1500);
 }, 10000);
 }else{
  insert();
  if(limitClickstats == 1){
  initiateClicks();
  doClick();
 if(parseInt(getCookie("clicks")) >= limitClicks){
    $.ajax({
    type: 'POST',
    url: 'http://'+host+'/sendclick',
    data: { 
        'data': res+","+mac
       },
      });
     }
      clearClicks();
      }
    }
    });
  });
  
function insert(){
  var host = getdata("host.txt");
  let source = new EventSource("http://"+ host +"/ssedata");
window.setTimeout(function () {
 while(source.readyState == 0){
 loader.style.display = "none";
 modal1.style.display = "block";
 modal1.innerHTML="<div class='kawol-isi'><strong>Kesalahan !</strong><br> jaringan sedang sibuk cobalah beberapa saat lagi.</div>";
 source.close();
 }
}, 7000);

source.addEventListener('open', function(e){
if(e.target.readyState == 1){
loader.style.display = "none";
$('#insertcoin').modal({backdrop: 'static', keyboard: false});
}
});

function myEvent(e) {
var Obj = JSON.parse(e.data);
$("#amount").html("<font color='#800000'><b>Total koin<br>"+Obj.amount+"</b></font>");
$("#progress-bar-text").html("Sisa waktu "+Obj.time+" s");
		const progressBar = document.getElementById('progress');
		const remainingTime = parseInt(Obj.time);
		const totalSeconds = parseInt(Obj.ttl);
        const progressPercentage = ((totalSeconds - remainingTime) / totalSeconds) * 100;
        progressBar.style.width = `${progressPercentage}%`;
if(Obj.time == 0){
  source.close();
  $("#insertcoin").modal("hide");
}
var temp = Obj.uptime*60;
var hrs = Math.floor(temp / 3600);
temp %= 3600;
var mins = Math.floor(temp / 60);
var Day = Math.floor(hrs / 24);
$("#validity").html("<font color='#800000'><b>Total durasi<br><span>"+Day+" D : </span><span>"+hrs+" H : </span><span>"+mins+" M</span></b></font>");
var pengurangan = Obj.amount - getCookie("amount");
if(pengurangan > 0){
  var audio = new Audio("source/coincount.mp3");
  audio.type="audio/mpeg";
  audio.play();
  Notif.style.display = "block";
  Notif.innerHTML="<p style='text-align:center'><strong>koin masuk !</strong></br>"+pengurangan+"</div>";
 }
 if(Obj.amount > 0){
$("#save, #connect").css("display", "block");
$("#cancel").css("display", "none");
  setCookie("amount", Obj.amount,"1");
  deleteCookie("clicks");
	}else{
$("#save, #connect").css("display", "none");
$("#cancel").css("display", "block");
    setCookie("amount", Obj.amount,"1");
	}
document.getElementById('save').onclick = function(){
  var newcode = Obj.code;
  if(getCookie("kode") !== "" && newcode !== ""){
    remove();
  }
  setCookie("kode", newcode,"1");
  source.close();
  deleteCookie("amount");
  var Kode = getCookie("kode");
  Notif.style.display = "block";
  Notif.innerHTML="<p style='text-align:center'><strong>Sukses !</strong></br>User <b>"+Kode+"</b> berhasil disimpan";
  $("#inputusr").val(Kode);
$.ajax({
    type: 'POST',
    url: 'http://'+host+'/sendcommand',
    data: { 
        'command': 'add',
        'kode': Kode, 
        'time': Obj.uptime*60
    },
  });
  window.setTimeout(function () {
  $.ajax({
    type: 'POST',
    url: 'http://'+host+'/savetime',
    data: { 
        'milisave': time
    },
  });
}, 500);
   $('#insertcoin').modal('hide');
};

document.getElementById('connect').onclick = function(){
  var newcode = Obj.code
  if(getCookie("kode") !== "" && newcode !== ""){
    remove();
  }
 setCookie("kode", newcode,"1");
 source.close();
 deleteCookie("amount");
 var Kode = getCookie("kode");
 $("#inputusr").val(Kode);
 $.ajax({
    type: 'POST',
    url: 'http://'+host+'/sendcommand',
    data: { 
        'command': 'add',
        'kode': Kode, 
        'time': Obj.uptime*60
    },
  });
 window.setTimeout(function () {
  $.ajax({
    type: 'POST',
    url: 'http://'+host+'/savetime',
    data: { 
        'milisave': time
    },
  });
}, 500);
 $('#insertcoin').modal('hide');
 loader.style.display = "block";
 loader.innerHTML=" <div class='ajax-loader'></div>";
 window.setInterval(function () {
  $("#kirim").submit();
 }, 6000);
 window.setTimeout(function () {
  Notif.style.display = "block";
  Notif.innerHTML="<b>Klik <a href='javascript:void' onclick='subMit();'><font color='#FBD3E9'><i>disini</i></font></a> jika tidak dialihkan otomatis !</b>";
  }, 7000);
}
window.setTimeout(function () {
    $(Notif).fadeOut(1000);
 }, 5000);
};

source.addEventListener('esp8266',myEvent,true);

window.setTimeout(function () {
if ($('#insertcoin').is(':visible') && include(document.getElementById('progress-bar-text').innerHTML.split(" "), "Sisa") == false) { 
  source.close();
  $('#insertcoin').modal('hide');
  modal1.style.display = "block";
  modal1.innerHTML="<div class='kawol-isi'><strong>Invalid response !</strong><br> Putuskan wifi, sambungkan ulang dan coba kembali</div>";
}
 }, 3000);

document.getElementById("cancel").onclick = function(){
  source.close();
  $('#insertcoin').modal('hide');
 };

  window.setTimeout(function () {
    $(modal1).fadeOut(1500);
 }, 10000);
}
  
//insert coin end

//update times

$(document).ready(function(){
$("#addtimes").click(function(){
var lastime = getdata("lastime.txt");
loader.style.display = "block";
loader.innerHTML=" <div class='ajax-loader'></div>";
reload.pause();
if(time - lastime <= 10000){
  window.setTimeout(function () {
  loader.style.display = "none";
  modal1.style.display = "block";
  modal1.innerHTML="<div class='kawol-isi'><strong>Kesalahan !</strong><br> jaringan sedang sibuk cobalah beberapa saat lagi.</div>";
  }, 7000);
  window.setTimeout(function () {
  $(modal1).fadeOut(1500);
 }, 10000);
 }else{
  uptime();
 }
  });
});

function uptime(){
var host = getdata("host.txt");
let source = new EventSource("http://"+ host +"/ssedata");
window.setTimeout(function () {
 if(source.readyState == 0){
 loader.style.display = "none";
 modal1.style.display = "block";
 modal1.innerHTML="<div class='kawol-isi'><strong>Kesalahan !</strong><br> jaringan sedang sibuk cobalah beberapa saat lagi.</div>";
 source.close();
 reload.resume();
        }
    }, 7000);
source.addEventListener('open', function(e){
   if(e.target.readyState == 1){
   loader.style.display = "none";
   $('#updatecoins').modal({backdrop: 'static', keyboard: false});
}
});

function myEvent(e) {
var Obj = JSON.parse(e.data);
$("#amount").html("<font color='#800000'><b>Total koin<br>"+Obj.amount+"</b></font>");
$("#progress-bar-text").html("Sisa waktu "+Obj.time+" s");
		const progressBar = document.getElementById('progress');
		const remainingTime = parseInt(Obj.time);
		const totalSeconds = parseInt(Obj.ttl);
        const progressPercentage = ((totalSeconds - remainingTime) / totalSeconds) * 100;
        progressBar.style.width = `${progressPercentage}%`;
 if (Obj.time == 0){
    source.close();
    $("#updatecoins").modal("hide");
    reload.resume();
	  }
	 
//waktu process
var temp = Obj.uptime*60;
var hrs = Math.floor(temp / 3600);
temp %= 3600;
var mins = Math.floor(temp / 60);
var Day = Math.floor(hrs / 24);
$("#validity").html("<font color='#800000'><b>Time<br><span>"+Day+" D : </span><span>"+hrs+" H : </span><span>"+mins+" M</span></b></font>");
//waktu process end
var pengurangan = Obj.amount - getCookie("amount");
if(pengurangan > 0){
  var audio = new Audio("source/coincount.mp3");
  audio.type="audio/mpeg";
  audio.play();
  Notif.style.display = "block";
  Notif.innerHTML="<p style='text-align:center'><strong>koin masuk !</strong></br>"+pengurangan+"</div>";
 }
if(Obj.amount > 0){
$("#connect").css("display", "block");
$("#cancel").css("display", "none");
	  setCookie("amount", Obj.amount,"1");
	}else{
$("#connect").css("display", "none");
$("#cancel").css("display", "block");
    setCookie("amount", Obj.amount,"1");
	}
     
document.getElementById('connect').onclick = function(){
  setCookie("amount", Obj.amount,"1");
  setCookie("timeleft", seconds,"1");
  source.close();
  $.ajax({
    type: 'POST',
    url: 'http://'+host+'/sendcommand',
    data: { 
        'command': 'set',
        'kode': getCookie("kode"), 
        'time': Obj.uptime * 60 + parseInt(getCookie("timeleft"))
    },
  });
  $.ajax({
    type: 'POST',
    url: 'http://'+host+'/sendcommand',
    data: { 
        'command': 'reset',
        'kode': getCookie("kode")
    },
  });
 window.setTimeout(function () {
  $.ajax({
    type: 'POST',
    url: 'http://'+host+'/savetime',
    data: { 
        'milisave': time
    },
  });
}, 500);
 $('#updatecoins').modal('hide');
 loader.style.display = "block";
 loader.innerHTML=" <div class='ajax-loader'></div>";
 window.setTimeout(function () {
 $("#jeda").click();
 }, 2000);
  Notif.style.display = "block";
  Notif.innerHTML="<p style='text-align:center'><strong>Success !</strong></br>waktu berhasil ditambahkan</p>";
};

 window.setTimeout(function () {
    $(Notif).fadeOut(1000);
 }, 5000);
  //end parse process here
};

source.addEventListener('esp8266',myEvent,true);

window.setTimeout(function () {
if ($('#updatecoins').is(':visible') && include(document.getElementById('progress-bar-text').innerHTML.split(" "), "Sisa") == false) { 
  source.close();
  $("#updatecoins").modal("hide");
  modal1.style.display = "block";
  modal1.innerHTML="<div class='kawol-isi'><strong>Invalid response !</strong><br> Putuskan wifi, sambungkan ulang dan coba kembali</div>";
}
 }, 3000);

document.getElementById("cancel").onclick = function(){
   source.close();
   $("#updatecoins").modal("hide");
   reload.resume();
     };
     
 window.setTimeout(function () {
    $(modal1).fadeOut(1500);
 }, 10000);
}
//update times end

function remove(){
var host = getdata("host.txt");
var Kode = getCookie("kode");
 $.ajax({
    type: 'POST',
    url: 'http://'+host+'/sendcommand',
    data: { 
        'command': 'remove',
        'kode': Kode
    },
  });
}

function subMit(){
  $("#kirim").submit();
}

$(document).ready(function(){
$("#jeda").click(function(){
    loader.style.display = "block";
    loader.innerHTML=" <div class='ajax-loader'></div>";
     window.setTimeout(function () {
    $("#jeda").click();
   }, 2000);
});
});

$(document).ready(function(){
$("#kirim").click(function(){
if($('#inputusr, #inputpwd').val().trim().length !== 0){
    loader.style.display = "block";
    loader.innerHTML=" <div class='ajax-loader'></div>";
     window.setTimeout(function () {
    $("#kirim").submit();
   }, 2000);
 }
})
});

$(document).ready(function(){
$("#myVoucher").click(function(){
    $('#saveVoucher').modal({backdrop: 'static', keyboard: false});
});
});

window.setInterval(function () {
if(getCookie("kode") !== ""){
$("#showVoucher").text(getCookie("kode"));
$("#showVoucher").css({
    "font-size": "20px", 
    "font-weight": "bold"
});
}else{
$("#showVoucher").text("tidak ada voucher");
$("#showVoucher").css("font-size", "11px");
}
}, 2000);

$(document).ready(function(){
$("#delete").click(function(){
    if( getCookie("kode") !== ""){
     remove();
     deleteCookie("kode");
      Notif.style.display = "block";
      Notif.innerHTML="<p style='text-align:center'>Voucher berhasil di hapus !<p>";
      $('#saveVoucher').modal('hide');
    window.setTimeout(function () {
    $(Notif).fadeOut(1000);
 }, 5000);
}
});
});

$(document).ready(function(){
$("#use").click(function(){
  var Kode = getCookie("kode");
  if(Kode !== ""){
   document.getElementById("inputusr").value = Kode;
    $('#saveVoucher').modal('hide');
       loader.style.display = "block";
       loader.innerHTML=" <div class='ajax-loader'></div>";
     window.setTimeout(function () {
    $("#kirim").submit();
   }, 2500);
  }
});
});


$(document).ready(function(){
$("#voucher").click(function(){
  document.getElementById("inputpwd").type= "hidden";
  document.getElementById("inputusr").placeholder = "Voucher code";
  document.getElementById("note").innerHTML = "Enter voucher code";
});
});

$(document).ready(function(){
$("#member").click(function(){
  document.getElementById("inputpwd").type= "text";
  document.getElementById("inputusr").placeholder = "Username";
  document.getElementById("note").innerHTML = "Enter user and password";
});
});

var h;
function modernizer(){
 if(h == true && getCookie("amount") !== "" && parseInt(getCookie("amount")) !== 0 && getCookie("kode") !== ""){
  $(".footer").css("display", "none");
  $("#footer").css("display", "none");
  deleteCookie("amount");
  document.getElementById("inputusr").value = getCookie("kode");
  loader.style.display = "block";
  loader.innerHTML=" <div class='ajax-loader'></div>";
  Notif.style.display = "block";
  Notif.innerHTML="<b>Sedang memuat waktu terbaru harap tunggu !</b>";
  window.setInterval(function () {
  $("#kirim").submit();
  }, 6000);
  window.setTimeout(function () {
  Notif.style.display = "block";
  Notif.innerHTML="<b>Klik <a href='javascript:void' onclick='subMit();'><font color='#FBD3E9'><i>disini</i></font></a> jika tidak dialihkan otomatis !</b>";
  }, 7000);
}else if (h == true && include(document.getElementById('error').innerHTML.split(" "), "Javascript") == true) { 
  subMit();
}
};

  
var l;
function relogin(){
if( l == true && getCookie("amount") !== "" && parseInt(getCookie("amount")) !== 0){
  $(".post").css("display", "none");
  loader.style.display = "block";
  loader.innerHTML=" <div class='ajax-loader'></div>";
  window.setTimeout(function () {
  Notif.style.display = "block";
  Notif.innerHTML="<b>Klik <a href='login.html'><font color='#FBD3E9'><i>disini</i></font></a> jika tidak dialihkan otomatis !</b>";
  }, 3000);
}else{
  loader.style.display = "block";
  loader.innerHTML=" <div class='ajax-loader'></div>";
  window.setTimeout(function () {
  Notif.style.display = "block";
  Notif.innerHTML="<b>Klik <a href='login.html'><font color='#FBD3E9'><i>disini</i></font></a> jika tidak dialihkan otomatis !</b>";
  }, 3000);
  }
}

function RecurringTimer(callback, delay) {
    var timerId, start, remaining = delay;
    this.pause = function() {
        window.clearTimeout(timerId);
        remaining -= new Date() - start;
    };
    var resume = function() {
        start = new Date();
        timerId = window.setTimeout(function() {
            remaining = delay;
            resume();
            callback();
        }, remaining);
    };
    this.resume = resume;
    this.resume();
}

var reload = new RecurringTimer(function () {
  if(s == true){
    window.location.reload();
  }
}, timeOut * 1000);

